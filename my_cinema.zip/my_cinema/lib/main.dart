import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'screens/shell.dart';
import 'services/download_manager.dart';
import 'services/library_store.dart';
import 'services/settings_store.dart';
import 'services/sources.dart';
import 'services/tmdb_service.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final settings = await SettingsStore.load();
  final library = await LibraryStore.load();
  final downloads = await DownloadManager.load();

  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider.value(value: settings),
      ChangeNotifierProvider.value(value: library),
      ChangeNotifierProvider.value(value: downloads),
      Provider.value(value: TmdbService(settings)),
      Provider.value(value: SourceResolver(settings)),
    ],
    child: const MyCinemaApp(),
  ));
}

class MyCinemaApp extends StatelessWidget {
  const MyCinemaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'سينماي',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const Shell(),
    );
  }
}
