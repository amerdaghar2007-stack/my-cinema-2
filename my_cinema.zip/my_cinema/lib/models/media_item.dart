const _img = 'https://image.tmdb.org/t/p';

/// عنصر واحد (فيلم / مسلسل / فيلم من الأرشيف).
/// type: movie | tv | archive
class MediaItem {
  final String id;
  final String type;
  final String title;
  final String originalTitle;
  final String overview;
  final String? posterUrl;
  final String? backdropUrl;
  final int? year;
  final double rating;
  final List<String> genres;
  final int seasons;
  final int? runtime;

  const MediaItem({
    required this.id,
    required this.type,
    required this.title,
    String? originalTitle,
    this.overview = '',
    this.posterUrl,
    this.backdropUrl,
    this.year,
    this.rating = 0,
    this.genres = const [],
    this.seasons = 1,
    this.runtime,
  }) : originalTitle = originalTitle ?? title;

  String get key => '$type:$id';
  bool get isTv => type == 'tv';
  bool get isArchive => type == 'archive';

  MediaItem withOverview(String o) => MediaItem(
        id: id,
        type: type,
        title: title,
        originalTitle: originalTitle,
        overview: o,
        posterUrl: posterUrl,
        backdropUrl: backdropUrl,
        year: year,
        rating: rating,
        genres: genres,
        seasons: seasons,
        runtime: runtime,
      );

  factory MediaItem.fromTmdb(Map<String, dynamic> j, {String? type}) {
    final t = type ??
        (j['media_type'] as String? ?? (j['title'] != null ? 'movie' : 'tv'));
    final date = (j['release_date'] ?? j['first_air_date'] ?? '') as String;
    final title = (j['title'] ?? j['name'] ?? '') as String;
    final ert = j['episode_run_time'];
    final runtimeRaw =
        j['runtime'] ?? ((ert is List && ert.isNotEmpty) ? ert.first : null);
    return MediaItem(
      id: j['id'].toString(),
      type: t,
      title: title,
      originalTitle: (j['original_title'] ?? j['original_name'] ?? title) as String,
      overview: (j['overview'] ?? '') as String,
      posterUrl:
          j['poster_path'] != null ? '$_img/w500${j['poster_path']}' : null,
      backdropUrl:
          j['backdrop_path'] != null ? '$_img/w780${j['backdrop_path']}' : null,
      year: date.length >= 4 ? int.tryParse(date.substring(0, 4)) : null,
      rating: (j['vote_average'] as num?)?.toDouble() ?? 0,
      genres: ((j['genres'] as List?) ?? const [])
          .map((g) => (g as Map)['name'].toString())
          .toList(),
      seasons: (j['number_of_seasons'] as num?)?.toInt() ?? 1,
      runtime: (runtimeRaw as num?)?.toInt(),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'title': title,
        'originalTitle': originalTitle,
        'overview': overview,
        'posterUrl': posterUrl,
        'backdropUrl': backdropUrl,
        'year': year,
        'rating': rating,
        'genres': genres,
        'seasons': seasons,
        'runtime': runtime,
      };

  factory MediaItem.fromJson(Map<String, dynamic> j) => MediaItem(
        id: j['id'] as String,
        type: j['type'] as String,
        title: j['title'] as String,
        originalTitle: j['originalTitle'] as String?,
        overview: (j['overview'] as String?) ?? '',
        posterUrl: j['posterUrl'] as String?,
        backdropUrl: j['backdropUrl'] as String?,
        year: j['year'] as int?,
        rating: (j['rating'] as num?)?.toDouble() ?? 0,
        genres: ((j['genres'] as List?) ?? const []).cast<String>(),
        seasons: (j['seasons'] as int?) ?? 1,
        runtime: j['runtime'] as int?,
      );
}

class Episode {
  final int number;
  final String name;
  final String overview;
  final String? still;
  const Episode(this.number, this.name, this.overview, this.still);
}

class TmdbDetails {
  final MediaItem item;
  final List<MediaItem> similar;
  final List<String> cast;
  const TmdbDetails(this.item, this.similar, this.cast);
}

/// خيار تشغيل واحد (جودة / مصدر) لعنصر معيّن.
class StreamOption {
  final String label;
  final String url;
  final String sourceName;
  final Map<String, String> headers;
  const StreamOption({
    required this.label,
    required this.url,
    required this.sourceName,
    this.headers = const {},
  });
}
