import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/media_item.dart';
import '../services/download_manager.dart';
import '../services/library_store.dart';
import '../services/sources.dart';
import '../services/tmdb_service.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/common.dart';
import 'player_screen.dart';
import 'settings_screen.dart';

class DetailsScreen extends StatefulWidget {
  const DetailsScreen({super.key, required this.item});
  final MediaItem item;
  @override
  State<DetailsScreen> createState() => _DetailsScreenState();
}

class _DetailsScreenState extends State<DetailsScreen> {
  late final Future<TmdbDetails> _f;
  Future<List<Episode>>? _eps;
  int _season = 1;
  int _episode = 1;

  MediaItem get item => widget.item;

  @override
  void initState() {
    super.initState();
    final tmdb = context.read<TmdbService>();
    _f = item.isArchive
        ? Future.value(TmdbDetails(item, const [], const []))
        : tmdb.details(item);
    if (item.isTv) {
      // نكمل من آخر موسم/حلقة شاهدتها
      final h = context
          .read<LibraryStore>()
          .historyList
          .where((e) => e.item.key == item.key && e.season != null);
      if (h.isNotEmpty) {
        _season = h.first.season!;
        _episode = h.first.episode ?? 1;
      }
      _eps = tmdb.season(item.id, _season);
    }
  }

  String get _historyKey =>
      item.isTv ? '${item.key}|s$_season|e$_episode' : item.key;

  String get _fullTitle =>
      item.isTv ? '${item.title}  S$_season E$_episode' : item.title;

  void _changeSeason(int n) {
    setState(() {
      _season = n;
      _episode = 1;
      _eps = context.read<TmdbService>().season(item.id, n);
    });
  }

  Future<List<StreamOption>?> _resolve() async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    var opts = <StreamOption>[];
    try {
      opts = await context
          .read<SourceResolver>()
          .resolve(item, season: _season, episode: _episode);
    } catch (_) {}
    if (!mounted) return null;
    Navigator.of(context, rootNavigator: true).pop();
    if (opts.isEmpty) {
      _noSource();
      return null;
    }
    return opts;
  }

  void _noSource() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('مفيش مصدر متاح'),
        content: const Text(
          'ملقيناش ملف قانوني للعنوان ده.\n\n'
          '• لو عندك سيرفر Jellyfin بأفلامك، ضيفه من الإعدادات.\n'
          '• أو افتح تبويب "الملكية العامة" في الرئيسية وشوف الأفلام المتاحة.',
          style: TextStyle(height: 1.6),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إغلاق')),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const SettingsScreen()));
            },
            child: const Text('الإعدادات'),
          ),
        ],
      ),
    );
  }

  Future<void> _play() async {
    final opts = await _resolve();
    if (opts == null || !mounted) return;
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => PlayerScreen(
        args: PlayerArgs(
          title: _fullTitle,
          options: opts,
          historyKey: _historyKey,
          item: item,
          season: item.isTv ? _season : null,
          episode: item.isTv ? _episode : null,
        ),
      ),
    ));
  }

  Future<void> _download() async {
    final opts = await _resolve();
    if (opts == null || !mounted) return;
    final direct = opts.where((o) => isDirectFile(o.url)).toList();
    if (direct.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('المصدر ده بث مباشر (m3u8) ومينفعش يتحمّل.')));
      return;
    }
    StreamOption? pick = direct.first;
    if (direct.length > 1) {
      pick = await showModalBottomSheet<StreamOption>(
        context: context,
        backgroundColor: AppColors.surface,
        builder: (_) => SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('اختار الجودة / الملف',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              ),
              for (final o in direct)
                ListTile(
                  title: Text(o.label),
                  trailing: const Icon(Icons.download_rounded),
                  onTap: () => Navigator.pop(context, o),
                ),
            ],
          ),
        ),
      );
    }
    if (pick == null || !mounted) return;
    await context.read<DownloadManager>().enqueue(
          id: _historyKey,
          title: _fullTitle,
          posterUrl: item.posterUrl,
          url: pick.url,
          headers: pick.headers,
        );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('بدأ التحميل — تابعه من تبويب التحميلات.')));
  }

  @override
  Widget build(BuildContext context) {
    final lib = context.watch<LibraryStore>();
    return Scaffold(
      body: FutureBuilder<TmdbDetails>(
        future: _f,
        builder: (context, snap) {
          final d = snap.data;
          final it = d?.item ?? item;
          return ListView(
            padding: EdgeInsets.zero,
            children: [
              _header(it),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: 96,
                          child: AspectRatio(
                            aspectRatio: 2 / 3,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: NetImage(it.posterUrl),
                            ),
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(it.title,
                                  style: const TextStyle(
                                      fontSize: 22, fontWeight: FontWeight.bold)),
                              const SizedBox(height: 8),
                              metaLine(it),
                              if (it.runtime != null && it.runtime! > 0) ...[
                                const SizedBox(height: 6),
                                Text('${it.runtime} دقيقة',
                                    style: const TextStyle(
                                        color: AppColors.textDim, fontSize: 13)),
                              ],
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    Wrap(
                      spacing: 10,
                      runSpacing: 10,
                      children: [
                        GradientButton(
                            label: 'تشغيل',
                            icon: Icons.play_arrow_rounded,
                            onTap: _play),
                        _chip(
                          lib.inList(item) ? Icons.check_rounded : Icons.add_rounded,
                          lib.inList(item) ? 'في قائمتي' : 'أضف إلى القائمة',
                          () => lib.toggleList(item),
                        ),
                        _chip(Icons.download_rounded, 'تحميل', _download),
                      ],
                    ),
                    if (item.isTv) ...[
                      const SizedBox(height: 22),
                      _seasons(it),
                    ],
                    if (it.overview.isNotEmpty) ...[
                      const SizedBox(height: 22),
                      const Text('القصة',
                          style:
                              TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Text(it.overview,
                          style: const TextStyle(
                              height: 1.7, color: Color(0xFFD0D3DA))),
                    ],
                    if (d != null && d.cast.isNotEmpty) ...[
                      const SizedBox(height: 18),
                      Text('طاقم التمثيل: ${d.cast.join('، ')}',
                          style: const TextStyle(
                              color: AppColors.textDim, height: 1.6, fontSize: 13)),
                    ],
                  ],
                ),
              ),
              if (d != null) SectionRow(title: 'أعمال مشابهة', items: d.similar),
              const SizedBox(height: 20),
            ],
          );
        },
      ),
    );
  }

  Widget _header(MediaItem it) {
    return AspectRatio(
      aspectRatio: 16 / 9,
      child: Stack(
        fit: StackFit.expand,
        children: [
          NetImage(it.backdropUrl ?? it.posterUrl),
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Colors.black54, Colors.transparent, AppColors.bg],
                stops: [0, 0.5, 1],
              ),
            ),
          ),
          Positioned(
            top: MediaQuery.of(context).padding.top + 4,
            right: 6,
            child: IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () => Navigator.pop(context),
            ),
          ),
          Center(
            child: GestureDetector(
              onTap: _play,
              child: Container(
                width: 62,
                height: 62,
                decoration: const BoxDecoration(
                    gradient: accentGradient, shape: BoxShape.circle),
                child: const Icon(Icons.play_arrow_rounded,
                    color: Colors.black, size: 40),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _chip(IconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: AppColors.surface2,
          borderRadius: BorderRadius.circular(30),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 19),
            const SizedBox(width: 6),
            Text(label, style: const TextStyle(fontSize: 14)),
          ],
        ),
      ),
    );
  }

  Widget _seasons(MediaItem it) {
    final count = it.seasons < 1 ? 1 : it.seasons;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('الحلقات',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.white24),
                borderRadius: BorderRadius.circular(8),
              ),
              child: DropdownButton<int>(
                value: _season > count ? 1 : _season,
                underline: const SizedBox.shrink(),
                dropdownColor: AppColors.surface2,
                items: [
                  for (var n = 1; n <= count; n++)
                    DropdownMenuItem(value: n, child: Text('الموسم $n')),
                ],
                onChanged: (v) {
                  if (v != null) _changeSeason(v);
                },
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        FutureBuilder<List<Episode>>(
          future: _eps,
          builder: (_, s) {
            final eps = s.data ?? const <Episode>[];
            if (s.connectionState != ConnectionState.done) {
              return const Padding(
                padding: EdgeInsets.all(16),
                child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
              );
            }
            if (eps.isEmpty) {
              return const Text('لا توجد بيانات حلقات',
                  style: TextStyle(color: AppColors.textDim));
            }
            final cur = eps.where((e) => e.number == _episode);
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final e in eps)
                      GestureDetector(
                        onTap: () => setState(() => _episode = e.number),
                        child: Container(
                          width: 52,
                          height: 44,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: e.number == _episode
                                ? AppColors.accent.withAlpha(50)
                                : AppColors.surface2,
                            borderRadius: BorderRadius.circular(8),
                            border: e.number == _episode
                                ? Border.all(color: AppColors.accent)
                                : null,
                          ),
                          child: Text(
                            e.number.toString().padLeft(2, '0'),
                            style: TextStyle(
                              color: e.number == _episode
                                  ? AppColors.accent
                                  : Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
                if (cur.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  Text('الحلقة ${cur.first.number}: ${cur.first.name}',
                      style: const TextStyle(
                          color: AppColors.textDim, fontSize: 13)),
                ],
              ],
            );
          },
        ),
      ],
    );
  }
}
