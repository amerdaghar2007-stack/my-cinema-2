import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/download_manager.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/common.dart';
import 'player_screen.dart';

class DownloadsScreen extends StatelessWidget {
  const DownloadsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final dm = context.watch<DownloadManager>();
    final used = dm.tasks.fold<int>(0, (a, t) => a + t.received);
    return SafeArea(
      bottom: false,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
            child: Row(
              children: [
                const Text('التحميلات',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const Spacer(),
                Text('المساحة المستخدمة: ${fmtBytes(used)}',
                    style: const TextStyle(color: AppColors.textDim, fontSize: 12)),
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'الملفات محفوظة داخل التطبيق فقط ومش بتظهر في المعرض. التحميل بيكمل وإنت فاتح التطبيق.',
              style: TextStyle(color: AppColors.textDim, fontSize: 12, height: 1.5),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: dm.tasks.isEmpty
                ? const Center(
                    child: Text('لسه مفيش تحميلات',
                        style: TextStyle(color: AppColors.textDim)))
                : ListView.builder(
                    itemCount: dm.tasks.length,
                    itemBuilder: (_, i) => _TaskTile(task: dm.tasks[i]),
                  ),
          ),
        ],
      ),
    );
  }
}

class _TaskTile extends StatelessWidget {
  const _TaskTile({required this.task});
  final DownloadTask task;

  String get _status {
    switch (task.status) {
      case DlStatus.downloading:
        return 'جاري التحميل ${(task.progress * 100).toStringAsFixed(0)}% · '
            '${fmtBytes(task.received)}${task.total > 0 ? ' / ${fmtBytes(task.total)}' : ''}';
      case DlStatus.paused:
        return 'متوقف · ${fmtBytes(task.received)}';
      case DlStatus.done:
        return 'تم · ${fmtBytes(task.received)}';
      case DlStatus.failed:
        return 'فشل التحميل';
    }
  }

  @override
  Widget build(BuildContext context) {
    final dm = context.read<DownloadManager>();
    final done = task.status == DlStatus.done;
    return InkWell(
      onTap: done
          ? () => Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => PlayerScreen(
                  args: PlayerArgs(title: task.title, localPath: task.path),
                ),
              ))
          : null,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(
          children: [
            SizedBox(
              width: 56,
              height: 84,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: NetImage(task.posterUrl),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(task.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  if (!done)
                    LinearProgressIndicator(
                      value: task.total > 0 ? task.progress : null,
                      minHeight: 4,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  const SizedBox(height: 6),
                  Text(_status,
                      style: TextStyle(
                          fontSize: 12,
                          color: task.status == DlStatus.failed
                              ? Colors.redAccent
                              : AppColors.textDim)),
                ],
              ),
            ),
            if (task.status == DlStatus.downloading)
              IconButton(
                  icon: const Icon(Icons.pause_rounded),
                  onPressed: () => dm.pause(task)),
            if (task.status == DlStatus.paused || task.status == DlStatus.failed)
              IconButton(
                  icon: const Icon(Icons.play_arrow_rounded),
                  onPressed: () => dm.resume(task)),
            if (done)
              const Icon(Icons.play_circle_outline_rounded, color: AppColors.accent),
            IconButton(
              icon: const Icon(Icons.delete_outline_rounded),
              onPressed: () => dm.remove(task),
            ),
          ],
        ),
      ),
    );
  }
}
