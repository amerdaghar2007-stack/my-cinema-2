import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/media_item.dart';
import '../services/settings_store.dart';
import '../services/sources.dart';
import '../services/tmdb_service.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'search_screen.dart';
import 'settings_screen.dart';

typedef Loader = Future<List<MediaItem>> Function();

class _Section {
  final String title;
  final Loader load;
  final bool ranked;
  const _Section(this.title, this.load, {this.ranked = false});
}

class _TabDef {
  final String title;
  final Loader? hero;
  final List<_Section> sections;
  final bool needsTmdb;
  const _TabDef(this.title, this.hero, this.sections, {this.needsTmdb = true});
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tc;
  late final List<_TabDef> _tabs;

  @override
  void initState() {
    super.initState();
    final t = context.read<TmdbService>();
    final a = ArchiveSource();
    _tabs = [
      _TabDef('الشائع', t.trending, [
        _Section('أفلام رائجة', t.popularMovies, ranked: true),
        _Section('مسلسلات رائجة', t.popularTv, ranked: true),
        _Section('قريباً في السينما', t.upcoming),
        _Section('الدراما التركية',
            () => t.discover('tv', {'with_original_language': 'tr'})),
        _Section('الدراما الكورية',
            () => t.discover('tv', {'with_original_language': 'ko'})),
        _Section('مسلسلات عربية',
            () => t.discover('tv', {'with_original_language': 'ar'})),
      ]),
      _TabDef('أفلام', t.nowPlaying, [
        _Section('الأكثر مشاهدة', t.popularMovies, ranked: true),
        _Section('الأعلى تقييماً', t.topMovies),
        _Section('قريباً', t.upcoming),
        _Section('أفلام عربية',
            () => t.discover('movie', {'with_original_language': 'ar'})),
        _Section('أفلام أنمي',
            () => t.discover('movie', {'with_genres': '16', 'with_original_language': 'ja'})),
      ]),
      _TabDef('مسلسلات', t.popularTv, [
        _Section('رائجة الآن', t.popularTv, ranked: true),
        _Section('الأعلى تقييماً', t.topTv),
        _Section('تُعرض حالياً', t.onAirTv),
      ]),
      _TabDef('أنمي',
          () => t.discover('tv', {'with_genres': '16', 'with_original_language': 'ja'}), [
        _Section('أنميات لا تفوتك',
            () => t.discover('tv', {'with_genres': '16', 'with_original_language': 'ja'}),
            ranked: true),
        _Section('رسوم متحركة غربية',
            () => t.discover('tv', {'with_genres': '16', 'with_original_language': 'en'})),
      ]),
      _TabDef('كوري',
          () => t.discover('tv', {'with_original_language': 'ko'}), [
        _Section('دراما كورية رائجة',
            () => t.discover('tv', {'with_original_language': 'ko'}),
            ranked: true),
        _Section('أفلام كورية',
            () => t.discover('movie', {'with_original_language': 'ko'})),
      ]),
      _TabDef('عربي',
          () => t.discover('tv', {'with_original_language': 'ar'}), [
        _Section('مسلسلات عربية',
            () => t.discover('tv', {'with_original_language': 'ar'}),
            ranked: true),
        _Section('أفلام عربية',
            () => t.discover('movie', {'with_original_language': 'ar'})),
      ]),
      _TabDef('الملكية العامة', null, [
        _Section('الأكثر مشاهدة', () => a.browse(), ranked: true),
        _Section('سينما كلاسيكية',
            () => a.browse(query: 'collection:classic_cinema')),
        _Section('أفلام الخيال العلمي',
            () => a.browse(query: 'subject:"science fiction" AND collection:feature_films')),
        _Section('كوميديا',
            () => a.browse(query: 'subject:comedy AND collection:feature_films')),
      ], needsTmdb: false),
    ];
    _tc = TabController(length: _tabs.length, vsync: this);
  }

  @override
  void dispose() {
    _tc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
            child: GestureDetector(
              onTap: () => Navigator.of(context)
                  .push(MaterialPageRoute(builder: (_) => const SearchScreen())),
              child: Container(
                height: 48,
                padding: const EdgeInsets.symmetric(horizontal: 14),
                decoration: BoxDecoration(
                  color: AppColors.surface2,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.search, color: AppColors.textDim),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text('ابحث عن فيلم أو مسلسل...',
                          style: TextStyle(color: AppColors.textDim)),
                    ),
                    Text('بحث',
                        style: TextStyle(
                            color: AppColors.accent, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ),
          ),
          TabBar(
            controller: _tc,
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            dividerColor: Colors.transparent,
            indicatorColor: AppColors.accent,
            labelColor: Colors.white,
            unselectedLabelColor: AppColors.textDim,
            labelStyle: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
            tabs: [for (final t in _tabs) Tab(text: t.title)],
          ),
          Expanded(
            child: TabBarView(
              controller: _tc,
              children: [for (final t in _tabs) _FeedTab(def: t)],
            ),
          ),
        ],
      ),
    );
  }
}

class _FeedTab extends StatefulWidget {
  const _FeedTab({required this.def});
  final _TabDef def;
  @override
  State<_FeedTab> createState() => _FeedTabState();
}

class _FeedTabState extends State<_FeedTab>
    with AutomaticKeepAliveClientMixin {
  Future<List<MediaItem>>? _hero;
  late List<Future<List<MediaItem>>> _rows;
  String? _lastKey;

  @override
  bool get wantKeepAlive => true;

  void _start() {
    _hero = widget.def.hero?.call();
    _rows = [for (final s in widget.def.sections) s.load()];
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final key = context.watch<SettingsStore>().tmdbKey;
    if (widget.def.needsTmdb && key.isEmpty) return const _SetupCard();
    if (_lastKey != key) {
      _lastKey = key;
      _start();
    }
    return RefreshIndicator(
      onRefresh: () async => setState(_start),
      child: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          if (_hero != null)
            FutureBuilder<List<MediaItem>>(
              future: _hero,
              builder: (_, s) {
                if (s.hasError) return _ErrorBox(onRetry: () => setState(_start));
                final items = (s.data ?? [])
                    .where((e) => e.backdropUrl != null)
                    .take(6)
                    .toList();
                if (items.isEmpty) return const SizedBox(height: 260);
                return _Hero(items: items);
              },
            ),
          const SizedBox(height: 16),
          for (var i = 0; i < _rows.length; i++)
            FutureBuilder<List<MediaItem>>(
              future: _rows[i],
              builder: (_, s) {
                if (s.connectionState != ConnectionState.done) {
                  return const SizedBox(
                      height: 200,
                      child: Center(
                          child: SizedBox(
                              width: 22,
                              height: 22,
                              child: CircularProgressIndicator(strokeWidth: 2))));
                }
                if (s.hasError) return const SizedBox.shrink();
                return SectionRow(
                  title: widget.def.sections[i].title,
                  items: s.data ?? [],
                  ranked: widget.def.sections[i].ranked,
                );
              },
            ),
        ],
      ),
    );
  }
}

class _Hero extends StatefulWidget {
  const _Hero({required this.items});
  final List<MediaItem> items;
  @override
  State<_Hero> createState() => _HeroState();
}

class _HeroState extends State<_Hero> {
  final _pc = PageController();
  int _page = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (!_pc.hasClients) return;
      final next = (_page + 1) % widget.items.length;
      _pc.animateToPage(next,
          duration: const Duration(milliseconds: 450), curve: Curves.easeOut);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 300,
      child: Stack(
        children: [
          PageView.builder(
            controller: _pc,
            itemCount: widget.items.length,
            onPageChanged: (i) => setState(() => _page = i),
            itemBuilder: (_, i) {
              final it = widget.items[i];
              return GestureDetector(
                onTap: () => openDetails(context, it),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    NetImage(it.backdropUrl),
                    const DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Colors.transparent, AppColors.bg],
                          stops: [0.35, 1],
                        ),
                      ),
                    ),
                    Positioned(
                      right: 16,
                      left: 16,
                      bottom: 34,
                      child: Row(
                        children: [
                          Container(
                            width: 46,
                            height: 46,
                            decoration: const BoxDecoration(
                                gradient: accentGradient, shape: BoxShape.circle),
                            child: const Icon(Icons.play_arrow_rounded,
                                color: Colors.black, size: 30),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(it.title,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        fontSize: 22, fontWeight: FontWeight.bold)),
                                const SizedBox(height: 4),
                                metaLine(it),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
          Positioned(
            bottom: 12,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                for (var i = 0; i < widget.items.length; i++)
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    width: i == _page ? 18 : 6,
                    height: 6,
                    decoration: BoxDecoration(
                      color: i == _page ? AppColors.accent : Colors.white38,
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SetupCard extends StatelessWidget {
  const _SetupCard();
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.vpn_key_outlined, size: 54, color: AppColors.accent),
            const SizedBox(height: 16),
            const Text('محتاج مفتاح TMDB مجاني',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text(
              'سجّل في themoviedb.org ← الإعدادات ← API وانسخ المفتاح، وبعدها الصقه في إعدادات التطبيق. '
              'ده اللي بيجيب البوسترات والأسماء والتقييمات.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.textDim, height: 1.6),
            ),
            const SizedBox(height: 20),
            GradientButton(
              label: 'افتح الإعدادات',
              icon: Icons.settings,
              onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const SettingsScreen())),
            ),
          ],
        ),
      ),
    );
  }
}

class _ErrorBox extends StatelessWidget {
  const _ErrorBox({required this.onRetry});
  final VoidCallback onRetry;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 260,
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('تعذّر تحميل المحتوى. اتأكد من الإنترنت ومن المفتاح.',
                style: TextStyle(color: AppColors.textDim)),
            TextButton(onPressed: onRetry, child: const Text('إعادة المحاولة')),
          ],
        ),
      ),
    );
  }
}
