import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/settings_store.dart';
import '../services/sources.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'player_screen.dart';
import 'settings_screen.dart';

class LiveTvScreen extends StatefulWidget {
  const LiveTvScreen({super.key});
  @override
  State<LiveTvScreen> createState() => _LiveTvScreenState();
}

class _LiveTvScreenState extends State<LiveTvScreen> {
  Future<List<M3uChannel>>? _f;
  String _sig = '';
  String _group = 'الكل';
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final urls = context.watch<SettingsStore>().m3uUrls;
    final sig = urls.join('|');
    if (_f == null || sig != _sig) {
      _sig = sig;
      _group = 'الكل';
      _f = urls.isEmpty ? Future.value(<M3uChannel>[]) : M3uSource.loadAll(urls);
    }
    return SafeArea(
      bottom: false,
      child: urls.isEmpty
          ? _empty(context)
          : FutureBuilder<List<M3uChannel>>(
              future: _f,
              builder: (context, s) {
                if (s.connectionState != ConnectionState.done) {
                  return const Center(child: CircularProgressIndicator());
                }
                final all = s.data ?? const <M3uChannel>[];
                if (all.isEmpty) return _empty(context, failed: true);
                final groupNames = {for (final c in all) c.group}.toList()..sort();
                final groups = ['الكل', ...groupNames];
                final list = all.where((c) {
                  final okG = _group == 'الكل' || c.group == _group;
                  final okQ = _query.isEmpty ||
                      c.name.toLowerCase().contains(_query.toLowerCase());
                  return okG && okQ;
                }).toList();
                return Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                      child: TextField(
                        onChanged: (v) => setState(() => _query = v),
                        decoration: InputDecoration(
                          hintText: 'ابحث عن قناة...',
                          prefixIcon: const Icon(Icons.search),
                          filled: true,
                          fillColor: AppColors.surface2,
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide.none),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 44,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        itemCount: groups.length,
                        separatorBuilder: (_, __) => const SizedBox(width: 8),
                        itemBuilder: (_, i) => ChoiceChip(
                          label: Text(groups[i]),
                          selected: _group == groups[i],
                          onSelected: (_) => setState(() => _group = groups[i]),
                        ),
                      ),
                    ),
                    Expanded(
                      child: GridView.builder(
                        padding: const EdgeInsets.all(16),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3,
                          mainAxisSpacing: 12,
                          crossAxisSpacing: 12,
                          childAspectRatio: 0.95,
                        ),
                        itemCount: list.length,
                        itemBuilder: (_, i) => _ChannelTile(channel: list[i]),
                      ),
                    ),
                  ],
                );
              },
            ),
    );
  }

  Widget _empty(BuildContext context, {bool failed = false}) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.live_tv_rounded, size: 54, color: AppColors.accent),
            const SizedBox(height: 14),
            Text(failed ? 'ملقيناش قنوات في القوائم' : 'مفيش قوائم قنوات',
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text(
              'ضيف رابط قائمة M3U (مصدر رسمي أو مجاني قانوني) من الإعدادات وتظهر هنا.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.textDim, height: 1.6),
            ),
            const SizedBox(height: 18),
            GradientButton(
              label: 'الإعدادات',
              icon: Icons.settings,
              onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const SettingsScreen())),
            ),
          ],
        ),
      ),
    );
  }
}

class _ChannelTile extends StatelessWidget {
  const _ChannelTile({required this.channel});
  final M3uChannel channel;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => PlayerScreen(
          args: PlayerArgs(
            title: channel.name,
            live: true,
            options: [
              StreamOption(label: channel.name, url: channel.url, sourceName: 'M3U'),
            ],
          ),
        ),
      )),
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
        ),
        padding: const EdgeInsets.all(8),
        child: Column(
          children: [
            Expanded(
              child: NetImage(channel.logo, fit: BoxFit.contain),
            ),
            const SizedBox(height: 6),
            Text(channel.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12)),
          ],
        ),
      ),
    );
  }
}
