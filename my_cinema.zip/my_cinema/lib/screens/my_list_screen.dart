import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/library_store.dart';
import '../theme.dart';
import '../widgets/common.dart';

class MyListScreen extends StatelessWidget {
  const MyListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = context.watch<LibraryStore>().myList;
    return Scaffold(
      appBar: AppBar(title: const Text('قائمتي')),
      body: items.isEmpty
          ? const Center(
              child: Text('القائمة فاضية', style: TextStyle(color: AppColors.textDim)))
          : GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                mainAxisSpacing: 14,
                crossAxisSpacing: 12,
                childAspectRatio: 0.52,
              ),
              itemCount: items.length,
              itemBuilder: (_, i) => PosterCard(item: items[i]),
            ),
    );
  }
}
