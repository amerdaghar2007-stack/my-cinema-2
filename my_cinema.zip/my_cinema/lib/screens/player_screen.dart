import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../models/media_item.dart';
import '../services/library_store.dart';
import '../theme.dart';
import '../utils.dart';

class PlayerArgs {
  final String title;
  final List<StreamOption> options;
  final String? localPath;
  final String historyKey;
  final MediaItem? item;
  final int? season;
  final int? episode;
  final bool live;

  const PlayerArgs({
    required this.title,
    this.options = const [],
    this.localPath,
    this.historyKey = '',
    this.item,
    this.season,
    this.episode,
    this.live = false,
  });
}

class PlayerScreen extends StatefulWidget {
  const PlayerScreen({super.key, required this.args});
  final PlayerArgs args;
  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  VideoPlayerController? _c;
  int _qi = 0;
  bool _show = true;
  bool _locked = false;
  bool _loading = true;
  bool _cover = false;
  bool _subsOn = true;
  String? _error;
  double _speed = 1;
  Timer? _hide;
  Timer? _saver;
  late final LibraryStore _lib;

  PlayerArgs get a => widget.args;

  @override
  void initState() {
    super.initState();
    _lib = context.read<LibraryStore>();
    SystemChrome.setPreferredOrientations(
        [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    WakelockPlus.enable();

    final saved = _lib.history[a.historyKey];
    final start = (saved != null && saved.progress < 0.95 && !a.live)
        ? Duration(milliseconds: saved.positionMs)
        : Duration.zero;
    _open(0, start);
    _saver = Timer.periodic(const Duration(seconds: 5), (_) => _save());
    _scheduleHide();
  }

  Future<void> _open(int index, Duration start) async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final VideoPlayerController c;
    if (a.localPath != null) {
      c = VideoPlayerController.file(File(a.localPath!));
    } else {
      final o = a.options[index];
      c = VideoPlayerController.networkUrl(Uri.parse(o.url),
          httpHeaders: o.headers);
    }
    try {
      await c.initialize();
      if (!mounted) {
        await c.dispose();
        return;
      }
      await c.setPlaybackSpeed(_speed);
      if (start > Duration.zero) await c.seekTo(start);
      await c.play();
      final old = _c;
      setState(() {
        _c = c;
        _qi = index;
        _loading = false;
      });
      WidgetsBinding.instance.addPostFrameCallback((_) => old?.dispose());
    } catch (_) {
      await c.dispose();
      if (mounted) {
        setState(() {
          _error = 'تعذّر تشغيل الفيديو. جرّب جودة أو مصدر آخر.';
          _loading = false;
        });
      }
    }
  }

  void _save({bool defer = false}) {
    final c = _c;
    final it = a.item;
    if (c == null || it == null || a.live || a.historyKey.isEmpty) return;
    final v = c.value;
    if (!v.isInitialized || v.duration.inMilliseconds <= 0) return;
    final pos = v.position.inMilliseconds;
    final dur = v.duration.inMilliseconds;
    void doSave() => _lib.saveProgress(a.historyKey, it, pos, dur,
        season: a.season, episode: a.episode);
    if (defer) {
      Future.microtask(doSave);
    } else {
      doSave();
    }
  }

  void _scheduleHide() {
    _hide?.cancel();
    _hide = Timer(const Duration(seconds: 4), () {
      if (mounted && (_c?.value.isPlaying ?? false)) {
        setState(() => _show = false);
      }
    });
  }

  void _toggle() {
    setState(() => _show = !_show);
    if (_show) _scheduleHide();
  }

  void _seekBy(int seconds) {
    final c = _c;
    if (c == null || a.live) return;
    final target = c.value.position + Duration(seconds: seconds);
    final max = c.value.duration;
    c.seekTo(target < Duration.zero ? Duration.zero : (target > max ? max : target));
    _scheduleHide();
  }

  Future<void> _pickSubtitle() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.any);
    final path = r?.files.single.path;
    if (path == null) return;
    final text = utf8.decode(await File(path).readAsBytes(), allowMalformed: true);
    final ClosedCaptionFile cf = path.toLowerCase().endsWith('.vtt')
        ? WebVTTCaptionFile(text)
        : SubRipCaptionFile(text);
    await _c?.setClosedCaptionFile(Future.value(cf));
    if (mounted) setState(() => _subsOn = true);
  }

  Duration _subOffset = Duration.zero;
  void _shiftSubs(int ms) {
    _subOffset += Duration(milliseconds: ms);
    _c?.setCaptionOffset(_subOffset);
  }

  @override
  void dispose() {
    _save(defer: true);
    _hide?.cancel();
    _saver?.cancel();
    _c?.dispose();
    WakelockPlus.disable();
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = _c;
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _toggle,
        onDoubleTapDown: (d) {
          if (_locked) return;
          final w = MediaQuery.of(context).size.width;
          _seekBy(d.globalPosition.dx < w / 2 ? -10 : 10);
        },
        onDoubleTap: () {},
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (c != null)
              SizedBox.expand(
                child: FittedBox(
                  fit: _cover ? BoxFit.cover : BoxFit.contain,
                  clipBehavior: Clip.hardEdge,
                  child: SizedBox(
                    width: c.value.size.width,
                    height: c.value.size.height,
                    child: VideoPlayer(c),
                  ),
                ),
              ),
            if (_loading) const Center(child: CircularProgressIndicator()),
            if (_error != null)
              Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(_error!, style: const TextStyle(color: Colors.white70)),
                    const SizedBox(height: 12),
                    TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('رجوع')),
                  ],
                ),
              ),
            if (c != null && _subsOn)
              Positioned(
                left: 40,
                right: 40,
                bottom: _show ? 76 : 24,
                child: ValueListenableBuilder<VideoPlayerValue>(
                  valueListenable: c,
                  builder: (_, v, __) {
                    final t = v.caption.text;
                    if (t.isEmpty) return const SizedBox.shrink();
                    return Center(
                      child: Container(
                        padding:
                            const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black54,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(t,
                            textAlign: TextAlign.center,
                            style: const TextStyle(fontSize: 18, height: 1.4)),
                      ),
                    );
                  },
                ),
              ),
            if (_show && !_locked && c != null) _controls(c),
            if (_show && _locked)
              Positioned(
                right: 24,
                top: 0,
                bottom: 0,
                child: Center(
                  child: IconButton.filledTonal(
                    icon: const Icon(Icons.lock_open_rounded),
                    onPressed: () => setState(() => _locked = false),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _controls(VideoPlayerController c) {
    return Stack(
      fit: StackFit.expand,
      children: [
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.black87, Colors.transparent, Colors.transparent, Colors.black87],
              stops: [0, 0.3, 0.7, 1],
            ),
          ),
        ),
        // الشريط العلوي
        Positioned(
          top: 8,
          left: 12,
          right: 12,
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () => Navigator.pop(context),
              ),
              Expanded(
                child: Text(a.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.bold)),
              ),
              if (!a.live)
                PopupMenuButton<String>(
                  tooltip: 'ترجمة',
                  icon: const Icon(Icons.subtitles_outlined),
                  color: AppColors.surface2,
                  onSelected: (v) {
                    if (v == 'pick') _pickSubtitle();
                    if (v == 'off') setState(() => _subsOn = false);
                    if (v == 'on') setState(() => _subsOn = true);
                    if (v == 'later') _shiftSubs(500);
                    if (v == 'earlier') _shiftSubs(-500);
                  },
                  itemBuilder: (_) => [
                    const PopupMenuItem(value: 'pick', child: Text('اختيار ملف ترجمة (.srt / .vtt)')),
                    PopupMenuItem(
                        value: _subsOn ? 'off' : 'on',
                        child: Text(_subsOn ? 'إيقاف الترجمة' : 'تشغيل الترجمة')),
                    const PopupMenuItem(value: 'later', child: Text('تأخير الترجمة 0.5 ث')),
                    const PopupMenuItem(value: 'earlier', child: Text('تقديم الترجمة 0.5 ث')),
                  ],
                ),
              if (a.options.length > 1 && a.localPath == null)
                PopupMenuButton<int>(
                  tooltip: 'الجودة',
                  icon: const Icon(Icons.high_quality_outlined),
                  color: AppColors.surface2,
                  onSelected: (i) =>
                      _open(i, c.value.position),
                  itemBuilder: (_) => [
                    for (var i = 0; i < a.options.length; i++)
                      PopupMenuItem(
                        value: i,
                        child: Text(a.options[i].label,
                            style: TextStyle(
                                color: i == _qi ? AppColors.accent : Colors.white)),
                      ),
                  ],
                ),
              PopupMenuButton<double>(
                tooltip: 'السرعة',
                icon: const Icon(Icons.speed_rounded),
                color: AppColors.surface2,
                onSelected: (v) {
                  setState(() => _speed = v);
                  c.setPlaybackSpeed(v);
                },
                itemBuilder: (_) => [
                  for (final s in const [0.5, 0.75, 1.0, 1.25, 1.5, 2.0])
                    PopupMenuItem(
                      value: s,
                      child: Text('${s}x',
                          style: TextStyle(
                              color: s == _speed ? AppColors.accent : Colors.white)),
                    ),
                ],
              ),
              IconButton(
                tooltip: 'ملاءمة الشاشة',
                icon: Icon(_cover
                    ? Icons.fit_screen_rounded
                    : Icons.aspect_ratio_rounded),
                onPressed: () => setState(() => _cover = !_cover),
              ),
            ],
          ),
        ),
        // أزرار الوسط
        Center(
          child: ValueListenableBuilder<VideoPlayerValue>(
            valueListenable: c,
            builder: (_, v, __) => Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (!a.live)
                  IconButton(
                    iconSize: 44,
                    icon: const Icon(Icons.replay_10_rounded),
                    onPressed: () => _seekBy(-10),
                  ),
                const SizedBox(width: 24),
                IconButton(
                  iconSize: 68,
                  icon: Icon(v.isPlaying
                      ? Icons.pause_circle_filled_rounded
                      : Icons.play_circle_fill_rounded),
                  onPressed: () {
                    v.isPlaying ? c.pause() : c.play();
                    _scheduleHide();
                  },
                ),
                const SizedBox(width: 24),
                if (!a.live)
                  IconButton(
                    iconSize: 44,
                    icon: const Icon(Icons.forward_10_rounded),
                    onPressed: () => _seekBy(10),
                  ),
              ],
            ),
          ),
        ),
        // الشريط السفلي
        Positioned(
          left: 20,
          right: 20,
          bottom: 8,
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.lock_outline_rounded),
                onPressed: () => setState(() => _locked = true),
              ),
              if (a.live)
                const Expanded(
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: Text('● بث مباشر',
                        style: TextStyle(color: Colors.redAccent)),
                  ),
                )
              else
                Expanded(
                  child: ValueListenableBuilder<VideoPlayerValue>(
                    valueListenable: c,
                    builder: (_, v, __) {
                      final dur = v.duration.inMilliseconds.toDouble();
                      final pos =
                          v.position.inMilliseconds.toDouble().clamp(0.0, dur);
                      return Row(
                        children: [
                          Text(fmtDuration(v.position),
                              style: const TextStyle(fontSize: 12)),
                          Expanded(
                            child: Directionality(
                              textDirection: TextDirection.ltr,
                              child: Slider(
                                value: pos,
                                max: dur <= 0 ? 1 : dur,
                                onChangeStart: (_) => _hide?.cancel(),
                                onChanged: (x) =>
                                    c.seekTo(Duration(milliseconds: x.toInt())),
                                onChangeEnd: (_) => _scheduleHide(),
                              ),
                            ),
                          ),
                          Text(fmtDuration(v.duration),
                              style: const TextStyle(fontSize: 12)),
                        ],
                      );
                    },
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}
