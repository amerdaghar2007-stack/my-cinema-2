import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/library_store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'my_list_screen.dart';
import 'settings_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final lib = context.watch<LibraryStore>();
    final history = lib.historyList;
    return SafeArea(
      bottom: false,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: const BoxDecoration(
                    gradient: accentGradient, shape: BoxShape.circle),
                child: const Icon(Icons.person_rounded, color: Colors.black, size: 32),
              ),
              const SizedBox(width: 14),
              const Text('سينماي الشخصي',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 22),
          _card(
            children: [
              ListTile(
                leading: const Icon(Icons.history_rounded),
                title: const Text('سجل المشاهدة'),
                trailing: history.isEmpty
                    ? null
                    : TextButton(
                        onPressed: lib.clearHistory, child: const Text('مسح')),
              ),
              if (history.isEmpty)
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 0, 16, 16),
                  child: Text('لسه ماشفتش حاجة',
                      style: TextStyle(color: AppColors.textDim)),
                )
              else
                SizedBox(
                  height: 190,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                    itemCount: history.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 12),
                    itemBuilder: (_, i) {
                      final h = history[i];
                      return GestureDetector(
                        onTap: () => openDetails(context, h.item),
                        child: SizedBox(
                          width: 110,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Stack(
                                    fit: StackFit.expand,
                                    children: [
                                      NetImage(h.item.posterUrl),
                                      Positioned(
                                        left: 0,
                                        right: 0,
                                        bottom: 0,
                                        child: LinearProgressIndicator(
                                          value: h.progress,
                                          minHeight: 3,
                                          backgroundColor: Colors.black54,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(h.item.title,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 12)),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
            ],
          ),
          const SizedBox(height: 14),
          _card(
            children: [
              ListTile(
                leading: const Icon(Icons.bookmark_border_rounded),
                title: const Text('قائمتي'),
                trailing: Text('${lib.myList.length}',
                    style: const TextStyle(color: AppColors.textDim)),
                onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const MyListScreen())),
              ),
              ListTile(
                leading: const Icon(Icons.settings_outlined),
                title: const Text('الإعدادات والمصادر'),
                trailing: const Icon(Icons.chevron_left_rounded),
                onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const SettingsScreen())),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _card({required List<Widget> children}) => Container(
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
      );
}
