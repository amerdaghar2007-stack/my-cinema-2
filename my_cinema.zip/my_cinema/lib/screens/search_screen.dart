import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/media_item.dart';
import '../services/library_store.dart';
import '../services/tmdb_service.dart';
import '../theme.dart';
import '../widgets/common.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _ctl = TextEditingController();
  Timer? _debounce;
  List<MediaItem>? _results;
  bool _loading = false;
  String? _error;
  int _filter = 0; // 0 الكل، 1 أفلام، 2 مسلسلات
  late final Future<List<MediaItem>> _hot;

  @override
  void initState() {
    super.initState();
    _hot = context.read<TmdbService>().trending().catchError((_) => <MediaItem>[]);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _ctl.dispose();
    super.dispose();
  }

  void _onChanged(String q) {
    _debounce?.cancel();
    if (q.trim().isEmpty) {
      setState(() {
        _results = null;
        _error = null;
      });
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 450), () => _run(q));
  }

  Future<void> _run(String q) async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final r = await context.read<TmdbService>().search(q.trim());
      if (!mounted) return;
      setState(() => _results = r);
    } catch (_) {
      if (mounted) setState(() => _error = 'تعذّر البحث. اتأكد من الإنترنت ومن مفتاح TMDB.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _useQuery(String q) {
    _ctl.text = q;
    _ctl.selection = TextSelection.collapsed(offset: q.length);
    _run(q);
  }

  @override
  Widget build(BuildContext context) {
    final lib = context.watch<LibraryStore>();
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Container(
          height: 44,
          margin: const EdgeInsets.only(left: 12),
          decoration: BoxDecoration(
            color: AppColors.surface2,
            borderRadius: BorderRadius.circular(12),
          ),
          child: TextField(
            controller: _ctl,
            autofocus: true,
            textInputAction: TextInputAction.search,
            onChanged: _onChanged,
            onSubmitted: (q) {
              lib.addSearch(q);
              _run(q);
            },
            decoration: InputDecoration(
              hintText: 'ابحث عن فيلم أو مسلسل...',
              hintStyle: const TextStyle(color: AppColors.textDim),
              border: InputBorder.none,
              prefixIcon: const Icon(Icons.search, color: AppColors.textDim),
              suffixIcon: _ctl.text.isEmpty
                  ? null
                  : IconButton(
                      icon: const Icon(Icons.close_rounded, size: 20),
                      onPressed: () {
                        _ctl.clear();
                        _onChanged('');
                      },
                    ),
            ),
          ),
        ),
      ),
      body: _results == null && !_loading ? _idle(lib) : _resultsView(lib),
    );
  }

  Widget _idle(LibraryStore lib) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (lib.recent.isNotEmpty) ...[
          Row(
            children: [
              const Text('حديث',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              const Spacer(),
              TextButton.icon(
                onPressed: lib.clearSearches,
                icon: const Icon(Icons.delete_outline, size: 18),
                label: const Text('مسح'),
              ),
            ],
          ),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final q in lib.recent)
                ActionChip(label: Text(q), onPressed: () => _useQuery(q)),
            ],
          ),
          const SizedBox(height: 24),
        ],
        const Text('الأكثر بحثاً 🔥',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        FutureBuilder<List<MediaItem>>(
          future: _hot,
          builder: (_, s) => Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final i in (s.data ?? []).take(10))
                ActionChip(label: Text(i.title), onPressed: () => _useQuery(i.title)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _resultsView(LibraryStore lib) {
    final all = _results ?? const <MediaItem>[];
    final shown = all.where((e) {
      if (_filter == 1) return e.type == 'movie';
      if (_filter == 2) return e.type == 'tv';
      return true;
    }).toList();
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: [
              for (final (i, t) in ['الكل', 'أفلام', 'مسلسلات'].indexed)
                Padding(
                  padding: const EdgeInsets.only(left: 8),
                  child: ChoiceChip(
                    label: Text(t),
                    selected: _filter == i,
                    onSelected: (_) => setState(() => _filter = i),
                  ),
                ),
            ],
          ),
        ),
        if (_loading) const LinearProgressIndicator(minHeight: 2),
        if (_error != null)
          Padding(
            padding: const EdgeInsets.all(24),
            child: Text(_error!, style: const TextStyle(color: AppColors.textDim)),
          ),
        Expanded(
          child: shown.isEmpty && !_loading && _error == null
              ? const Center(
                  child: Text('مفيش نتائج', style: TextStyle(color: AppColors.textDim)))
              : ListView.builder(
                  itemCount: shown.length,
                  itemBuilder: (_, i) {
                    final it = shown[i];
                    return InkWell(
                      onTap: () {
                        lib.addSearch(_ctl.text);
                        openDetails(context, it);
                      },
                      child: Padding(
                        padding:
                            const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        child: Row(
                          children: [
                            SizedBox(
                              width: 62,
                              height: 92,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: NetImage(it.posterUrl),
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(it.title,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                          fontSize: 16, fontWeight: FontWeight.bold)),
                                  const SizedBox(height: 6),
                                  metaLine(it),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}
