import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/settings_store.dart';
import '../services/sources.dart';
import '../theme.dart';
import '../widgets/common.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _tmdb, _jfUrl, _jfUser, _jfPass, _m3u;
  String? _jfResult;
  bool _testing = false;

  @override
  void initState() {
    super.initState();
    final s = context.read<SettingsStore>();
    _tmdb = TextEditingController(text: s.tmdbKey);
    _jfUrl = TextEditingController(text: s.jfUrl);
    _jfUser = TextEditingController(text: s.jfUser);
    _jfPass = TextEditingController(text: s.jfPass);
    _m3u = TextEditingController();
  }

  @override
  void dispose() {
    for (final c in [_tmdb, _jfUrl, _jfUser, _jfPass, _m3u]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    await context.read<SettingsStore>().saveKeys(
          tmdbKey: _tmdb.text,
          jfUrl: _jfUrl.text,
          jfUser: _jfUser.text,
          jfPass: _jfPass.text,
        );
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('تم الحفظ')));
  }

  Future<void> _testJellyfin() async {
    await _save();
    if (!mounted) return;
    setState(() {
      _testing = true;
      _jfResult = null;
    });
    try {
      final name = await JellyfinSource(context.read<SettingsStore>()).test();
      setState(() => _jfResult = '✓ اتصال ناجح بسيرفر: $name');
    } catch (_) {
      setState(() => _jfResult =
          '✗ فشل الاتصال. اتأكد من العنوان (مثال: http://192.168.1.10:8096) واسم المستخدم وكلمة السر.');
    } finally {
      if (mounted) setState(() => _testing = false);
    }
  }

  InputDecoration _dec(String label, {String? hint}) => InputDecoration(
        labelText: label,
        hintText: hint,
        filled: true,
        fillColor: AppColors.surface2,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
      );

  Widget _title(String t, String sub) => Padding(
        padding: const EdgeInsets.only(top: 24, bottom: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(t, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(sub,
                style: const TextStyle(color: AppColors.textDim, fontSize: 13, height: 1.5)),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    final s = context.watch<SettingsStore>();
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات والمصادر')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 40),
        children: [
          _title('مفتاح TMDB (إلزامي)',
              'مجاني من themoviedb.org ← الإعدادات ← API. بيجيب البوسترات والأسماء والتقييمات. '
              'ممكن تلصق المفتاح العادي (v3) أو التوكن الطويل (v4).'),
          TextField(controller: _tmdb, decoration: _dec('مفتاح TMDB')),
          _title('سيرفر Jellyfin الشخصي',
              'لو عندك سيرفر بأفلامك ومسلسلاتك، التطبيق بيدوّر فيه ويشغّل منه مباشرة.'),
          TextField(
              controller: _jfUrl,
              keyboardType: TextInputType.url,
              decoration: _dec('عنوان السيرفر', hint: 'http://192.168.1.10:8096')),
          const SizedBox(height: 10),
          TextField(controller: _jfUser, decoration: _dec('اسم المستخدم')),
          const SizedBox(height: 10),
          TextField(
              controller: _jfPass, obscureText: true, decoration: _dec('كلمة السر')),
          const SizedBox(height: 12),
          Row(
            children: [
              GradientButton(label: 'حفظ', icon: Icons.save_rounded, onTap: _save),
              const SizedBox(width: 10),
              OutlinedButton(
                onPressed: _testing ? null : _testJellyfin,
                child: _testing
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : const Text('اختبار الاتصال'),
              ),
            ],
          ),
          if (_jfResult != null)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Text(_jfResult!,
                  style: TextStyle(
                      color: _jfResult!.startsWith('✓')
                          ? AppColors.accent
                          : Colors.redAccent,
                      height: 1.5)),
            ),
          _title('قوائم القنوات (M3U)',
              'ضيف رابط قائمة قنوات M3U من مصدر رسمي أو مجاني قانوني، وتظهر في تبويب "القنوات".'),
          Row(
            children: [
              Expanded(
                child: TextField(
                    controller: _m3u,
                    keyboardType: TextInputType.url,
                    decoration: _dec('رابط القائمة', hint: 'https://.../playlist.m3u')),
              ),
              const SizedBox(width: 8),
              IconButton.filled(
                icon: const Icon(Icons.add_rounded),
                onPressed: () {
                  s.addM3u(_m3u.text);
                  _m3u.clear();
                },
              ),
            ],
          ),
          const SizedBox(height: 4),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton(
              onPressed: () =>
                  s.addM3u('https://iptv-org.github.io/iptv/index.m3u'),
              child: const Text('إضافة قائمة قنوات عامة (مشروع iptv-org)'),
            ),
          ),
          for (final u in s.m3uUrls)
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(u,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 13)),
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline_rounded),
                onPressed: () => s.removeM3u(u),
              ),
            ),
          _title('الملكية العامة (Internet Archive)',
              'شغّالة تلقائيًا بدون إعدادات: تبويب "الملكية العامة" في الرئيسية، '
              'وكمان بيدوّر فيها عن أي فيلم تفتحه.'),
        ],
      ),
    );
  }
}
