import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/download_manager.dart';
import 'downloads_screen.dart';
import 'home_screen.dart';
import 'live_tv_screen.dart';
import 'profile_screen.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _i = 0;

  @override
  Widget build(BuildContext context) {
    final active = context.watch<DownloadManager>().activeCount;
    return Scaffold(
      body: IndexedStack(
        index: _i,
        children: const [
          HomeScreen(),
          LiveTvScreen(),
          DownloadsScreen(),
          ProfileScreen(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _i,
        onDestinationSelected: (v) => setState(() => _i = v),
        destinations: [
          const NavigationDestination(
              icon: Icon(Icons.home_outlined),
              selectedIcon: Icon(Icons.home_rounded),
              label: 'الرئيسية'),
          const NavigationDestination(
              icon: Icon(Icons.live_tv_outlined),
              selectedIcon: Icon(Icons.live_tv_rounded),
              label: 'القنوات'),
          NavigationDestination(
              icon: Badge(
                isLabelVisible: active > 0,
                label: Text('$active'),
                child: const Icon(Icons.download_outlined),
              ),
              selectedIcon: const Icon(Icons.download_rounded),
              label: 'التحميلات'),
          const NavigationDestination(
              icon: Icon(Icons.person_outline),
              selectedIcon: Icon(Icons.person_rounded),
              label: 'أنا'),
        ],
      ),
    );
  }
}
