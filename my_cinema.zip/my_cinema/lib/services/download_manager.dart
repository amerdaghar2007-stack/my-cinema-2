import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../utils.dart';

enum DlStatus { downloading, paused, done, failed }

class DownloadTask {
  final String id;
  final String title;
  final String? posterUrl;
  final String url;
  final String path;
  final Map<String, String> headers;
  DlStatus status;
  int received;
  int total;

  DownloadTask({
    required this.id,
    required this.title,
    required this.posterUrl,
    required this.url,
    required this.path,
    this.headers = const {},
    this.status = DlStatus.paused,
    this.received = 0,
    this.total = 0,
  });

  double get progress => total <= 0 ? 0 : (received / total).clamp(0.0, 1.0);

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'poster': posterUrl,
        'url': url,
        'path': path,
        'headers': headers,
        'status': status.index,
        'received': received,
        'total': total,
      };

  factory DownloadTask.fromJson(Map<String, dynamic> j) => DownloadTask(
        id: j['id'] as String,
        title: j['title'] as String,
        posterUrl: j['poster'] as String?,
        url: j['url'] as String,
        path: j['path'] as String,
        headers: Map<String, String>.from(j['headers'] as Map? ?? {}),
        // أي تحميل كان شغّالًا عند إغلاق التطبيق يرجع "متوقف" ويمكن استئنافه
        status: DlStatus.values[j['status'] as int] == DlStatus.downloading
            ? DlStatus.paused
            : DlStatus.values[j['status'] as int],
        received: j['received'] as int,
        total: j['total'] as int,
      );
}

/// تحميل الأفلام إلى مساحة التطبيق الخاصة (لا تظهر في المعرض ولا مدير الملفات،
/// وتُحذف عند حذف التطبيق). يدعم الإيقاف والاستئناف.
/// ملاحظة: التحميل يعمل أثناء فتح التطبيق، ولا يدعم روابط البث m3u8.
class DownloadManager extends ChangeNotifier {
  DownloadManager._(this._p);
  final SharedPreferences _p;
  final Dio _dio = Dio();

  final List<DownloadTask> tasks = [];
  final Map<String, CancelToken> _tokens = {};

  static Future<DownloadManager> load() async {
    final m = DownloadManager._(await SharedPreferences.getInstance());
    try {
      final l = jsonDecode(m._p.getString('downloads') ?? '[]') as List;
      m.tasks.addAll(l
          .map((e) => DownloadTask.fromJson(Map<String, dynamic>.from(e as Map))));
    } catch (_) {}
    return m;
  }

  int get activeCount =>
      tasks.where((t) => t.status == DlStatus.downloading).length;

  DownloadTask? byId(String id) {
    for (final t in tasks) {
      if (t.id == id) return t;
    }
    return null;
  }

  Future<void> _save() => _p.setString(
      'downloads', jsonEncode(tasks.map((t) => t.toJson()).toList()));

  Future<Directory> _dir() async {
    final base = await getApplicationDocumentsDirectory();
    final d = Directory('${base.path}/movies');
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  Future<void> enqueue({
    required String id,
    required String title,
    required String? posterUrl,
    required String url,
    Map<String, String> headers = const {},
  }) async {
    if (byId(id) != null) return;
    final dir = await _dir();
    final ext = (Uri.tryParse(url)?.path.split('.').last ?? 'mp4').toLowerCase();
    final safeExt = ['mp4', 'm4v', 'webm', 'mkv'].contains(ext) ? ext : 'mp4';
    final task = DownloadTask(
      id: id,
      title: title,
      posterUrl: posterUrl,
      url: url,
      path: '${dir.path}/${safeFileName(id)}.$safeExt',
      headers: headers,
    );
    tasks.insert(0, task);
    await _save();
    _run(task);
  }

  Future<void> resume(DownloadTask t) => _run(t);

  void pause(DownloadTask t) {
    _tokens[t.id]?.cancel('pause');
  }

  Future<void> remove(DownloadTask t) async {
    _tokens[t.id]?.cancel('remove');
    tasks.remove(t);
    try {
      final f = File(t.path);
      if (await f.exists()) await f.delete();
    } catch (_) {}
    await _save();
    notifyListeners();
  }

  Future<void> _run(DownloadTask t) async {
    if (_tokens.containsKey(t.id)) return;
    final token = CancelToken();
    _tokens[t.id] = token;
    t.status = DlStatus.downloading;
    notifyListeners();

    final file = File(t.path);
    int existing = await file.exists() ? await file.length() : 0;
    RandomAccessFile? raf;
    try {
      final res = await _dio.get<ResponseBody>(
        t.url,
        cancelToken: token,
        options: Options(
          responseType: ResponseType.stream,
          receiveTimeout: Duration.zero,
          headers: {
            ...t.headers,
            if (existing > 0) 'range': 'bytes=$existing-',
          },
          validateStatus: (s) => s != null && s < 400,
        ),
      );
      // لو السيرفر تجاهل Range نبدأ من الصفر بدل ما نكمّل فوق ملف تالف
      if (existing > 0 && res.statusCode != 206) existing = 0;

      final len = int.tryParse(res.headers.value('content-length') ?? '');
      t.total = len != null ? existing + len : 0;
      t.received = existing;

      raf = await file.open(mode: existing > 0 ? FileMode.append : FileMode.write);
      final clock = Stopwatch()..start();
      await for (final chunk in res.data!.stream) {
        await raf.writeFrom(chunk);
        t.received += chunk.length;
        if (clock.elapsedMilliseconds > 400) {
          clock.reset();
          notifyListeners();
        }
      }
      t.status = DlStatus.done;
    } on DioException catch (e) {
      if (CancelToken.isCancel(e)) {
        t.status = DlStatus.paused;
      } else if (e.response?.statusCode == 416) {
        // الملف مكتمل أصلًا
        t.status = DlStatus.done;
      } else {
        t.status = DlStatus.failed;
      }
    } catch (_) {
      t.status = DlStatus.failed;
    } finally {
      await raf?.close();
      _tokens.remove(t.id);
      await _save();
      notifyListeners();
    }
  }
}
