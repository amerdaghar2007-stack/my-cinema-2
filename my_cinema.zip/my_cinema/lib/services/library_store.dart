import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/media_item.dart';

class HistoryEntry {
  final MediaItem item;
  final int positionMs;
  final int durationMs;
  final int? season;
  final int? episode;
  final int ts;
  const HistoryEntry(this.item, this.positionMs, this.durationMs, this.season,
      this.episode, this.ts);

  double get progress =>
      durationMs <= 0 ? 0 : (positionMs / durationMs).clamp(0.0, 1.0);

  Map<String, dynamic> toJson() => {
        'item': item.toJson(),
        'pos': positionMs,
        'dur': durationMs,
        'season': season,
        'episode': episode,
        'ts': ts,
      };

  factory HistoryEntry.fromJson(Map<String, dynamic> j) => HistoryEntry(
        MediaItem.fromJson(Map<String, dynamic>.from(j['item'] as Map)),
        j['pos'] as int,
        j['dur'] as int,
        j['season'] as int?,
        j['episode'] as int?,
        j['ts'] as int,
      );
}

/// سجل المشاهدة + قائمتي + عمليات البحث الأخيرة.
class LibraryStore extends ChangeNotifier {
  LibraryStore._(this._p);
  final SharedPreferences _p;

  final Map<String, HistoryEntry> history = {};
  final List<MediaItem> myList = [];
  final List<String> recent = [];

  static Future<LibraryStore> load() async {
    final s = LibraryStore._(await SharedPreferences.getInstance());
    try {
      final h = jsonDecode(s._p.getString('history') ?? '{}') as Map;
      h.forEach((k, v) => s.history[k as String] =
          HistoryEntry.fromJson(Map<String, dynamic>.from(v as Map)));
      final l = jsonDecode(s._p.getString('myList') ?? '[]') as List;
      s.myList.addAll(
          l.map((e) => MediaItem.fromJson(Map<String, dynamic>.from(e as Map))));
      s.recent.addAll(s._p.getStringList('recent') ?? []);
    } catch (_) {
      // بيانات تالفة: نبدأ من جديد
    }
    return s;
  }

  /// آخر ما شاهدته، عنصر واحد لكل فيلم/مسلسل.
  List<HistoryEntry> get historyList {
    final all = history.values.toList()..sort((a, b) => b.ts.compareTo(a.ts));
    final seen = <String>{};
    return all.where((e) => seen.add(e.item.key)).toList();
  }

  bool inList(MediaItem i) => myList.any((e) => e.key == i.key);

  Future<void> toggleList(MediaItem i) async {
    if (inList(i)) {
      myList.removeWhere((e) => e.key == i.key);
    } else {
      myList.insert(0, i);
    }
    await _p.setString('myList', jsonEncode(myList.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  void saveProgress(String key, MediaItem item, int pos, int dur,
      {int? season, int? episode}) {
    history[key] = HistoryEntry(item, pos, dur, season, episode,
        DateTime.now().millisecondsSinceEpoch);
    _p.setString(
        'history', jsonEncode(history.map((k, v) => MapEntry(k, v.toJson()))));
    notifyListeners();
  }

  Future<void> clearHistory() async {
    history.clear();
    await _p.remove('history');
    notifyListeners();
  }

  Future<void> addSearch(String q) async {
    q = q.trim();
    if (q.isEmpty) return;
    recent.remove(q);
    recent.insert(0, q);
    if (recent.length > 12) recent.removeLast();
    await _p.setStringList('recent', recent);
    notifyListeners();
  }

  Future<void> clearSearches() async {
    recent.clear();
    await _p.remove('recent');
    notifyListeners();
  }
}
