import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsStore extends ChangeNotifier {
  SettingsStore._(this._p);
  final SharedPreferences _p;

  static Future<SettingsStore> load() async =>
      SettingsStore._(await SharedPreferences.getInstance());

  String get tmdbKey => _p.getString('tmdbKey') ?? '';
  String get jfUrl => _p.getString('jfUrl') ?? '';
  String get jfUser => _p.getString('jfUser') ?? '';
  String get jfPass => _p.getString('jfPass') ?? '';
  List<String> get m3uUrls => _p.getStringList('m3uUrls') ?? [];

  bool get jellyfinConfigured => jfUrl.isNotEmpty && jfUser.isNotEmpty;

  Future<void> saveKeys({
    required String tmdbKey,
    required String jfUrl,
    required String jfUser,
    required String jfPass,
  }) async {
    await _p.setString('tmdbKey', tmdbKey.trim());
    await _p.setString('jfUrl', jfUrl.trim());
    await _p.setString('jfUser', jfUser.trim());
    await _p.setString('jfPass', jfPass);
    notifyListeners();
  }

  Future<void> addM3u(String url) async {
    final l = m3uUrls;
    if (url.trim().isEmpty || l.contains(url.trim())) return;
    l.add(url.trim());
    await _p.setStringList('m3uUrls', l);
    notifyListeners();
  }

  Future<void> removeM3u(String url) async {
    final l = m3uUrls..remove(url);
    await _p.setStringList('m3uUrls', l);
    notifyListeners();
  }
}
