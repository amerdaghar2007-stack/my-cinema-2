import 'dart:convert';

import 'package:dio/dio.dart';

import '../models/media_item.dart';
import 'settings_store.dart';

// ─────────────────────────────────────────────────────────────
// مصادر الفيديو. التطبيق مبني على 3 مصادر قانونية فقط:
//   1) سيرفرك الشخصي Jellyfin (أفلامك ومسلسلاتك أنت)
//   2) Internet Archive (أفلام الملكية العامة)
//   3) قوائم قنوات M3U التي تضيفها بنفسك
// ─────────────────────────────────────────────────────────────

dynamic _json(dynamic data) => data is String ? jsonDecode(data) : data;
String _s(dynamic v) => v is List ? (v.isEmpty ? '' : '${v.first}') : '${v ?? ''}';
String _norm(String s) => s.toLowerCase().replaceAll(RegExp(r'[^a-z0-9؀-ۿ]'), '');

/// يبحث في كل المصادر المفعّلة بالتوازي ويرجّع كل الخيارات.
class SourceResolver {
  SourceResolver(this.settings);
  final SettingsStore settings;

  Future<List<StreamOption>> resolve(MediaItem item,
      {int? season, int? episode}) async {
    final jobs = <Future<List<StreamOption>>>[];
    if (item.isArchive) {
      jobs.add(ArchiveSource().optionsFor(item.id));
    } else {
      if (settings.jellyfinConfigured) {
        jobs.add(JellyfinSource(settings).find(item, season, episode));
      }
      if (item.type == 'movie') jobs.add(ArchiveSource().findMovie(item));
    }
    final results = await Future.wait(
        jobs.map((f) => f.catchError((_) => <StreamOption>[])));
    return results.expand((e) => e).toList();
  }
}

// ───────────────────────── Jellyfin ─────────────────────────

class JellyfinSource {
  JellyfinSource(this.s);
  final SettingsStore s;

  static String? _token;
  static String? _userId;
  static String? _tokenFor;

  final Dio _dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 10),
    receiveTimeout: const Duration(seconds: 20),
  ));

  String get _base => s.jfUrl.replaceAll(RegExp(r'/+$'), '');
  static const _hdr =
      'MediaBrowser Client="MyCinema", Device="Android", DeviceId="my-cinema-app", Version="1.0.0"';

  Future<void> _auth() async {
    final key = '${s.jfUrl}|${s.jfUser}|${s.jfPass}';
    if (_token != null && _tokenFor == key) return;
    final r = await _dio.post(
      '$_base/Users/AuthenticateByName',
      data: {'Username': s.jfUser, 'Pw': s.jfPass},
      options: Options(headers: {'X-Emby-Authorization': _hdr}),
    );
    final d = _json(r.data) as Map;
    _token = d['AccessToken'] as String;
    _userId = (d['User'] as Map)['Id'] as String;
    _tokenFor = key;
  }

  Options get _opts =>
      Options(headers: {'X-Emby-Authorization': '$_hdr, Token="$_token"'});

  /// للتأكد من إعدادات السيرفر. يرجّع اسم السيرفر أو يرمي خطأ.
  Future<String> test() async {
    await _auth();
    final r = await _dio.get('$_base/System/Info/Public');
    return (_json(r.data) as Map)['ServerName'].toString();
  }

  StreamOption _stream(String id, String label) => StreamOption(
        label: label,
        url: '$_base/Videos/$id/stream?static=true&api_key=$_token',
        sourceName: 'Jellyfin',
      );

  Future<List<StreamOption>> find(
      MediaItem item, int? season, int? episode) async {
    await _auth();
    final types = item.type == 'movie' ? 'Movie' : 'Series';
    final names = <String>{item.originalTitle, item.title};
    for (final name in names) {
      final r = await _dio.get('$_base/Items',
          queryParameters: {
            'userId': _userId,
            'searchTerm': name,
            'includeItemTypes': types,
            'recursive': true,
            'fields': 'ProductionYear',
          },
          options: _opts);
      final items = ((_json(r.data) as Map)['Items'] as List).cast<Map>();
      if (items.isEmpty) continue;

      Map pick = items.first;
      final y = item.year;
      if (y != null) {
        for (final e in items) {
          final py = e['ProductionYear'];
          if (py is int && (py - y).abs() <= 1) {
            pick = e;
            break;
          }
        }
      }

      if (item.type == 'movie') {
        return [_stream(pick['Id'] as String, 'Jellyfin · الملف الأصلي')];
      }

      final er = await _dio.get('$_base/Shows/${pick['Id']}/Episodes',
          queryParameters: {'userId': _userId, 'season': season ?? 1},
          options: _opts);
      final eps = ((_json(er.data) as Map)['Items'] as List).cast<Map>();
      for (final e in eps) {
        if (e['IndexNumber'] == (episode ?? 1)) {
          return [_stream(e['Id'] as String, 'Jellyfin · الملف الأصلي')];
        }
      }
    }
    return [];
  }
}

// ───────────────────── Internet Archive ─────────────────────

class ArchiveSource {
  final Dio _dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 15),
    receiveTimeout: const Duration(seconds: 25),
  ));

  static String posterOf(String id) => 'https://archive.org/services/img/$id';

  Future<List<MediaItem>> browse({
    String query = 'collection:feature_films',
    String sort = 'downloads desc',
    int rows = 30,
  }) async {
    final docs = await _search('($query) AND mediatype:movies', sort, rows);
    return docs.map((d) {
      final id = _s(d['identifier']);
      return MediaItem(
        id: id,
        type: 'archive',
        title: _s(d['title']),
        overview: _s(d['description']),
        posterUrl: posterOf(id),
        backdropUrl: posterOf(id),
        year: int.tryParse(_s(d['year'])),
      );
    }).toList();
  }

  Future<List<Map>> _search(String q, String sort, int rows) async {
    final r = await _dio.get('https://archive.org/advancedsearch.php',
        queryParameters: {
          'q': q,
          'fl[]': ['identifier', 'title', 'year', 'description'],
          'sort[]': sort,
          'rows': rows,
          'page': 1,
          'output': 'json',
        });
    final d = _json(r.data) as Map;
    return ((d['response'] as Map)['docs'] as List).cast<Map>();
  }

  /// بحث عن فيلم TMDB داخل أفلام الملكية العامة (مطابقة صارمة للاسم).
  Future<List<StreamOption>> findMovie(MediaItem item) async {
    final t = item.originalTitle.replaceAll('"', '');
    final docs = await _search('title:("$t") AND mediatype:movies',
        'downloads desc', 4);
    for (final d in docs) {
      final a = _norm(_s(d['title']));
      final b = _norm(item.originalTitle);
      if (b.isNotEmpty && (a == b || a.startsWith(b))) {
        final opts = await optionsFor(_s(d['identifier']));
        if (opts.isNotEmpty) return opts;
      }
    }
    return [];
  }

  Future<List<StreamOption>> optionsFor(String identifier) async {
    final r = await _dio.get('https://archive.org/metadata/$identifier');
    final files = ((_json(r.data) as Map)['files'] as List?) ?? const [];
    final vids = files.cast<Map>().where((f) {
      final n = '${f['name']}'.toLowerCase();
      return n.endsWith('.mp4') || n.endsWith('.m4v') || n.endsWith('.webm');
    }).toList();
    vids.sort((a, b) => (int.tryParse('${b['size']}') ?? 0)
        .compareTo(int.tryParse('${a['size']}') ?? 0));
    return vids.take(4).map((f) {
      final name = '${f['name']}';
      final mb = ((int.tryParse('${f['size']}') ?? 0) / 1048576).round();
      final path = name.split('/').map(Uri.encodeComponent).join('/');
      return StreamOption(
        label: 'Archive · ${name.split('.').last.toUpperCase()}'
            '${mb > 0 ? ' · $mb MB' : ''}',
        url: 'https://archive.org/download/$identifier/$path',
        sourceName: 'Internet Archive',
      );
    }).toList();
  }
}

// ───────────────────────── M3U ─────────────────────────

class M3uChannel {
  final String name;
  final String url;
  final String? logo;
  final String group;
  const M3uChannel(this.name, this.url, this.logo, this.group);
}

class M3uSource {
  static final _attr = RegExp(r'([\w-]+)="([^"]*)"');

  static List<M3uChannel> parse(String text) {
    final out = <M3uChannel>[];
    String? name, logo, group;
    for (final raw in const LineSplitter().convert(text)) {
      final line = raw.trim();
      if (line.startsWith('#EXTINF')) {
        final attrs = {
          for (final m in _attr.allMatches(line)) m.group(1)!: m.group(2)!
        };
        logo = attrs['tvg-logo'];
        group = attrs['group-title'];
        final comma = line.lastIndexOf(',');
        name = comma >= 0 ? line.substring(comma + 1).trim() : null;
      } else if (line.isNotEmpty && !line.startsWith('#')) {
        if (name != null && name.isNotEmpty) {
          out.add(M3uChannel(name, line, logo, (group ?? '').isEmpty ? 'عام' : group!));
        }
        name = logo = group = null;
      }
    }
    return out;
  }

  static Future<List<M3uChannel>> loadAll(List<String> urls) async {
    final dio = Dio(BaseOptions(
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 40),
      responseType: ResponseType.plain,
    ));
    final all = <M3uChannel>[];
    for (final u in urls) {
      try {
        final r = await dio.get<String>(u);
        all.addAll(parse(r.data ?? ''));
      } catch (_) {
        // قائمة لا تعمل: نتخطاها
      }
    }
    return all;
  }
}
