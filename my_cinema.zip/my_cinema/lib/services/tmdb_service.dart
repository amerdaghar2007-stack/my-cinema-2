import 'package:dio/dio.dart';

import '../models/media_item.dart';
import 'settings_store.dart';

/// بيانات الأفلام والمسلسلات (بوسترات، أسماء، تقييم، بحث) من TMDB.
class TmdbService {
  TmdbService(this.settings);
  final SettingsStore settings;

  final Dio _dio = Dio(BaseOptions(
    baseUrl: 'https://api.themoviedb.org/3',
    connectTimeout: const Duration(seconds: 15),
    receiveTimeout: const Duration(seconds: 20),
  ));
  final Map<String, Map<String, dynamic>> _cache = {};

  Future<Map<String, dynamic>> _get(String path,
      [Map<String, dynamic>? q]) async {
    final key = settings.tmdbKey;
    if (key.isEmpty) throw StateError('no_key');
    final params = <String, dynamic>{'language': 'ar', ...?q};
    final ck = '$key|$path|$params';
    final hit = _cache[ck];
    if (hit != null) return hit;
    // مفتاح v4 (توكن طويل) يُرسل في الهيدر، ومفتاح v3 كـ api_key
    final bearer = key.length > 60;
    if (!bearer) params['api_key'] = key;
    final r = await _dio.get(
      path,
      queryParameters: params,
      options: Options(headers: bearer ? {'Authorization': 'Bearer $key'} : null),
    );
    final data = Map<String, dynamic>.from(r.data as Map);
    _cache[ck] = data;
    return data;
  }

  Future<List<MediaItem>> _list(String path,
      {Map<String, dynamic>? q, String? type}) async {
    final j = await _get(path, q);
    final results = (j['results'] as List?) ?? const [];
    return results
        .map((e) => Map<String, dynamic>.from(e as Map))
        .where((e) => e['media_type'] != 'person' && e['poster_path'] != null)
        .map((e) => MediaItem.fromTmdb(e, type: type))
        .toList();
  }

  Future<List<MediaItem>> trending() => _list('/trending/all/week');
  Future<List<MediaItem>> popularMovies() => _list('/movie/popular', type: 'movie');
  Future<List<MediaItem>> topMovies() => _list('/movie/top_rated', type: 'movie');
  Future<List<MediaItem>> upcoming() => _list('/movie/upcoming', type: 'movie');
  Future<List<MediaItem>> nowPlaying() => _list('/movie/now_playing', type: 'movie');
  Future<List<MediaItem>> popularTv() => _list('/tv/popular', type: 'tv');
  Future<List<MediaItem>> topTv() => _list('/tv/top_rated', type: 'tv');
  Future<List<MediaItem>> onAirTv() => _list('/tv/on_the_air', type: 'tv');

  /// type: movie | tv — مثال: discover('tv', {'with_original_language': 'ko'})
  Future<List<MediaItem>> discover(String type, Map<String, dynamic> q) =>
      _list('/discover/$type',
          q: {'sort_by': 'popularity.desc', ...q}, type: type);

  Future<List<MediaItem>> search(String query) =>
      _list('/search/multi', q: {'query': query});

  Future<TmdbDetails> details(MediaItem base) async {
    final path = '/${base.type}/${base.id}';
    final j = await _get(path, {'append_to_response': 'similar,credits'});
    var item = MediaItem.fromTmdb(j, type: base.type);
    if (item.overview.isEmpty) {
      try {
        final en = await _get(path, {'language': 'en-US'});
        item = item.withOverview((en['overview'] ?? '') as String);
      } catch (_) {}
    }
    final sim = ((j['similar']?['results'] as List?) ?? const [])
        .map((e) => Map<String, dynamic>.from(e as Map))
        .where((e) => e['poster_path'] != null)
        .map((e) => MediaItem.fromTmdb(e, type: base.type))
        .toList();
    final cast = ((j['credits']?['cast'] as List?) ?? const [])
        .take(8)
        .map((e) => (e as Map)['name'].toString())
        .toList();
    return TmdbDetails(item, sim, cast);
  }

  Future<List<Episode>> season(String tvId, int season) async {
    final j = await _get('/tv/$tvId/season/$season');
    return ((j['episodes'] as List?) ?? const []).map((e) {
      final m = e as Map;
      return Episode(
        (m['episode_number'] as num).toInt(),
        (m['name'] ?? '') as String,
        (m['overview'] ?? '') as String,
        m['still_path'] != null
            ? 'https://image.tmdb.org/t/p/w300${m['still_path']}'
            : null,
      );
    }).toList();
  }
}
