import 'package:flutter/material.dart';

class AppColors {
  static const bg = Color(0xFF0E0F13);
  static const surface = Color(0xFF1A1C22);
  static const surface2 = Color(0xFF262932);
  static const accent = Color(0xFF2EE6A6);
  static const accent2 = Color(0xFF1CB5E0);
  static const textDim = Color(0xFF9AA0AC);
  static const star = Color(0xFFF5B50A);
}

const accentGradient = LinearGradient(
  colors: [AppColors.accent2, AppColors.accent],
);

ThemeData buildTheme() {
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: AppColors.bg,
    colorScheme: const ColorScheme.dark(
      primary: AppColors.accent,
      secondary: AppColors.accent2,
      surface: AppColors.surface,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.bg,
      elevation: 0,
      scrolledUnderElevation: 0,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: AppColors.surface,
      indicatorColor: AppColors.accent.withAlpha(40),
      labelTextStyle: WidgetStateProperty.all(const TextStyle(fontSize: 12)),
    ),
    sliderTheme: const SliderThemeData(
      activeTrackColor: AppColors.accent,
      thumbColor: AppColors.accent,
      inactiveTrackColor: Colors.white24,
      trackHeight: 3,
    ),
  );
}
