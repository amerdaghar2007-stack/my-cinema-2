String fmtDuration(Duration d) {
  final h = d.inHours;
  final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
  final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
  return h > 0 ? '$h:$m:$s' : '$m:$s';
}

String fmtBytes(int bytes) {
  if (bytes <= 0) return '0 MB';
  const mb = 1024 * 1024;
  if (bytes < 1024 * mb) return '${(bytes / mb).toStringAsFixed(1)} MB';
  return '${(bytes / (1024 * mb)).toStringAsFixed(2)} GB';
}

String safeFileName(String s) =>
    s.replaceAll(RegExp(r'[^\w؀-ۿ\-]+'), '_');

bool isDirectFile(String url) {
  final p = Uri.tryParse(url)?.path.toLowerCase() ?? '';
  return !(p.endsWith('.m3u8') || p.endsWith('.m3u'));
}
