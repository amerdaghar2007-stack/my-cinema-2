import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../models/media_item.dart';
import '../screens/details_screen.dart';
import '../theme.dart';

void openDetails(BuildContext context, MediaItem item) {
  Navigator.of(context).push(
    MaterialPageRoute(builder: (_) => DetailsScreen(item: item)),
  );
}

class NetImage extends StatelessWidget {
  const NetImage(this.url, {super.key, this.fit = BoxFit.cover});
  final String? url;
  final BoxFit fit;

  @override
  Widget build(BuildContext context) {
    final box = Container(
      color: AppColors.surface2,
      child: const Center(child: Icon(Icons.movie_outlined, color: Colors.white24)),
    );
    if (url == null || url!.isEmpty) return box;
    return CachedNetworkImage(
      imageUrl: url!,
      fit: fit,
      placeholder: (_, __) => Container(color: AppColors.surface2),
      errorWidget: (_, __, ___) => box,
    );
  }
}

class PosterCard extends StatelessWidget {
  const PosterCard({super.key, required this.item, this.width = 120, this.rank});
  final MediaItem item;
  final double width;
  final int? rank;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      child: GestureDetector(
        onTap: () => openDetails(context, item),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AspectRatio(
              aspectRatio: 2 / 3,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    NetImage(item.posterUrl),
                    if (rank != null)
                      Positioned(
                        bottom: -8,
                        left: 6,
                        child: Text(
                          '$rank',
                          style: TextStyle(
                            fontSize: 64,
                            fontWeight: FontWeight.w900,
                            color: Colors.white.withAlpha(220),
                            shadows: const [
                              Shadow(blurRadius: 10, color: Colors.black)
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 6),
            Text(item.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 13)),
          ],
        ),
      ),
    );
  }
}

class SectionRow extends StatelessWidget {
  const SectionRow({
    super.key,
    required this.title,
    required this.items,
    this.ranked = false,
    this.width = 120,
  });
  final String title;
  final List<MediaItem> items;
  final bool ranked;
  final double width;

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(title,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: width * 1.5 + 34,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (_, i) => PosterCard(
                item: items[i],
                width: width,
                rank: ranked && i < 10 ? i + 1 : null,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class RatingText extends StatelessWidget {
  const RatingText(this.rating, {super.key});
  final double rating;

  @override
  Widget build(BuildContext context) {
    if (rating <= 0) return const SizedBox.shrink();
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(rating.toStringAsFixed(1),
            style: const TextStyle(color: AppColors.star, fontSize: 13)),
        const SizedBox(width: 2),
        const Icon(Icons.star_rounded, color: AppColors.star, size: 15),
      ],
    );
  }
}

class GradientButton extends StatelessWidget {
  const GradientButton({
    super.key,
    required this.label,
    required this.onTap,
    this.icon,
  });
  final String label;
  final IconData? icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
        decoration: BoxDecoration(
          gradient: accentGradient,
          borderRadius: BorderRadius.circular(30),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) Icon(icon, color: Colors.black, size: 20),
            if (icon != null) const SizedBox(width: 6),
            Text(label,
                style: const TextStyle(
                    color: Colors.black, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

Widget metaLine(MediaItem i) {
  final parts = <String>[
    if (i.year != null) '${i.year}',
    i.isTv ? 'مسلسل' : (i.isArchive ? 'ملكية عامة' : 'فيلم'),
    ...i.genres.take(2),
  ];
  return Wrap(
    spacing: 8,
    crossAxisAlignment: WrapCrossAlignment.center,
    children: [
      RatingText(i.rating),
      Text(parts.join('  |  '),
          style: const TextStyle(color: AppColors.textDim, fontSize: 13)),
    ],
  );
}
